import urllib.request
import urllib.parse
import json

# 1. Login as test user
req = urllib.request.Request('http://localhost:8080/api/auth/login', 
                             data=json.dumps({"email":"testuser@example.com", "password":"password"}).encode('utf-8'),
                             headers={'Content-Type': 'application/json'},
                             method='POST')
try:
    with urllib.request.urlopen(req) as response:
        login_res = json.loads(response.read().decode())
        token = login_res.get('token')
        print("Login success.")
except urllib.error.HTTPError as e:
    print("Login failed:", e.code, e.read().decode())
    exit(1)

# 2. Get profile to find all my ideas
req = urllib.request.Request('http://localhost:8080/api/users/me/profile', 
                                headers={"Authorization": f"Bearer {token}"})
with urllib.request.urlopen(req) as res:
    profile = json.loads(res.read().decode())
    ideas = profile.get("ideas", [])

print(f"Found {len(ideas)} total ideas for test user.")

# Find duplicates
seen_titles = set()
duplicates = []

# Assuming the ideas are returned in some order. We want to keep one.
for idea in ideas:
    title = idea.get("title")
    if title == "AI- powered system":
        if title in seen_titles:
            duplicates.append(idea.get("id"))
        else:
            seen_titles.add(title)

print(f"Found {len(duplicates)} duplicate 'AI- powered system' ideas to delete.")

# 3. Delete duplicates
for d_id in duplicates:
    del_req = urllib.request.Request(f'http://localhost:8080/api/ideas/{d_id}', 
                                headers={"Authorization": f"Bearer {token}"},
                                method='DELETE')
    try:
        with urllib.request.urlopen(del_req) as res:
            print(f"Deleted idea ID: {d_id}")
    except urllib.error.HTTPError as e:
        print(f"Failed to delete idea ID {d_id}:", e.code, e.read().decode())

print("Cleanup complete.")
